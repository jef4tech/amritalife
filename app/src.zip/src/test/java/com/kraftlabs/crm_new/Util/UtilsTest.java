package com.kraftlabs.crm_new.Util;

import org.junit.Test;

/**
 * Created by ashik on 17/8/17.
 */
public class UtilsTest {
    @Test
    public void setBadgeCount() throws Exception {

    }

}