package com.kraftlabs.crm_new.Permission;

/**
 * Created by Alhazmy13 on 5/20/16.
 * Gota
 */
class GotaTags {


    static final String PERMISSIONS = "PERMISSIONS";
    public static final String MSG = "MSG";
    static final String REQ_ID = "REQ_ID";
}
