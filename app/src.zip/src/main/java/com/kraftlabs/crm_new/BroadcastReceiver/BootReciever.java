package com.kraftlabs.crm_new.BroadcastReceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by ashik on 1/7/17.
 */

public class BootReciever extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent arg1) {
        
    }

}
