package com.kraftlabs.crm_new.Models;

/**
 * Created by ajith on 14/10/15.
 */
public class Category {
    public String mName;


    public Category(String name) {
        mName = name;

    }
}
