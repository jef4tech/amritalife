/*
package com.kraftlabs.crm_new.Interfaces;

import android.support.v4.app.Fragment;

*/
/**
 * User: ashik
 * Date: 13/10/17
 * Time: 11:49 AM
 *//*


public interface OnFragmentTouched {
    public void onFragmentTouched(Fragment fragment, float x, float y);
}
*/
